<html>

<?php
    /*connexion à la base de données */
    $bdd= new PDO(dsn: "mysql:host=localhost;dbname=ceynteppcz_pan;charset=utf8",username: "ceynteppcz_phenyx",password: "f=W7I]8MaZ");
?>

<?php
    $id = $_GET['id'];

    $stmt = $bdd->prepare(query: "SELECT * FROM ressources WHERE id = ?");
    $stmt->execute(params: [$id]);

    $data = $stmt->fetch(PDO::FETCH_ASSOC);
?>

<head>
    <title><?php echo $data['titre']; ?></title>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="shortcut icon" href="../../logo_pan.png">
    <link rel="stylesheet" href="tests/ressources/style.css">
</head>
<header>
    <?php include 'header.php'; ?>
</header>
 <?php include 'menu.php'; ?>
<body>
   
    <main class="page">
        <!-- HAUT DE FICHE : gauche (titre + meta), droite (mots-clés) -->
        <section class="top-row">
            <div class="title-block">
                <p class="breadcrumb">Portail › Corpus › Grec › TLG</p>

                <h2 class="title"><?php echo $data['titre']; ?></h2>
                <p class="subtitle"><?php echo $data['sous_titre']; ?></p>

                <div class="meta-under-title" aria-label="Informations">
                    <span class="pill">Langue ancienne : <?php echo $data['langue_ancienne']; ?></span>
                    
                    <span class="pill">Langue d'usage : <?php echo $data['langue_usage']; ?></span>

                    <span class="pill">Type : <?php echo $data['type']; ?></span>

                    <span class="pill">Accès : <?php echo $data['acces']; ?></span>

                    <span class="pill">Période : <?php echo $data['periode']; ?></span>
                </div>
            </div>
            <aside class="keywords-right" aria-label="Mots-clés">
                <div class="kw-title">Mots-clés</div>
                <div class="kw-grid">
                    <a class="kw" href="#"><?php echo $data['mots_cles']; ?></a>
                    <a class="kw" href="#">#corpus</a>
                    <a class="kw" href="#">#philologie</a>
                    <a class="kw" href="#">#texte</a>
                    <a class="kw" href="#">#recherche</a>
                    <a class="kw" href="#">#base_de_données</a>
                    <a class="kw" href="#">#antiquité</a>
                </div>
            </aside>
        </section>

        <!-- ONGLETs -->
        <nav class="tabs" aria-label="Onglets">
            <button class="tab active" data-tab="resume" type="button">Résumé</button>
            <button class="tab" data-tab="usages" type="button">Usages & limites</button>
            <button class="tab" data-tab="aide" type="button">Aide & tutoriels</button>
            <button class="tab" data-tab="similaires" type="button">Ressources similaires</button>
            <button class="tab" data-tab="plus" type="button">En savoir plus</button>
        </nav>

        <section class="content">
            <div class="panel active" id="resume">
                <p><?php echo $data['resume']; ?></p>
            </div>

            <div class="panel" id="usages">
                <div class="columns">
                    <div class="col">
                        <h2>Usages</h2>
                        <ul>
                            <li>xxx</li>
                            <li>xxx</li>
                            <li>xxx</li>
                        </ul>
                    </div>
                    <div class="col">
                        <h2>Limites</h2>
                        <ul>
                            <li>xxx</li>
                            <li>xxx</li>
                            <li>xxx</li>
                        </ul>
                    </div>
                </div>
            </div>

            <div class="panel" id="aide">
                <p><?php echo $data['aide']; ?></p>
            </div>

            <div class="panel" id="similaires">
                <ul>
                    <li>xxx — xxx</li>
                    <li>xxx — xxx</li>
                </ul>
            </div>

            <div class="panel" id="plus">
                <p><?php echo $data['infos_en_plus']; ?></p>
            </div>
        </section>

        <div class="cta-row">
            <a class="btn-access" href="<?php echo $data['url']; ?>" target="_blank" rel="noopener">Accès au site</a>
        </div>





    </main>

    <script src="tests/ressources/tabs.js"></script>


</body>

</html>