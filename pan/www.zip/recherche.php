<?php

$bdd = new PDO("mysql:host=localhost;dbname=ceynteppcz_pan;charset=utf8","ceynteppcz_phenyx","f=W7I]8MaZ");

$recherche = strtolower(trim($_GET['q']));


$stmt = $bdd->prepare("
SELECT id, titre
FROM ressources
WHERE titre LIKE ?
OR sous_titre LIKE ?
OR alias LIKE ?
LIMIT 1
");

 /*si on ajoute un cri�re, il faut ajouter un "%".$recherche."%", */

$stmt->execute([
"%".$recherche."%",
"%".$recherche."%", 
"%".$recherche."%"
]);

$resultat = $stmt->fetch();

if($resultat){
    header("Location: ressources_2.php?id=".$resultat['id']);
    exit();
}

?>