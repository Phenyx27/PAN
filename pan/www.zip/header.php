<link rel="stylesheet" type="text/css" href="header.css">

<header class="site-header">
    
    <div class="header-wrapper">
        <a href="index.php"><img src="logo_pan.png" title="Retour à l'accueil" alt="Logo du portail" class="logo"/></a>
        <h1 class="site-title">Portail des Antiquités Numériques</h1>
    </div>
</header>