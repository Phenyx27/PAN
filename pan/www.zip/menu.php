<html>
<link rel="stylesheet" href="menu.css"/>

<div class="topnav">
  <a class="active" href="#home">Home</a>
  <a href="#about">About</a>
  <a href="#contact">Contact</a>
  <input type="text" placeholder="Search..">
  
</div>  
    
    
</html>
